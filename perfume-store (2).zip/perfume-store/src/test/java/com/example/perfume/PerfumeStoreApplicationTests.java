package com.example.perfume;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfumeStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
