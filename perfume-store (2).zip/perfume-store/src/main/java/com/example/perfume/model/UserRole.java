package com.example.perfume.model;

public enum UserRole {
    USER,
    ADMIN,
    GUEST
}
