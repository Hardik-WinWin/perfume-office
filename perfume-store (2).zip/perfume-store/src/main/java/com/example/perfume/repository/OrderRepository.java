package com.example.perfume.repository;

import com.example.perfume.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {

    List<Order> findByEmail(String email);

    Optional<Order> findByOrderId(String orderId);

    // ✅ New method to find an order using guest email and order ID
    Optional<Order> findByEmailAndOrderId(String email, String orderId);
}
