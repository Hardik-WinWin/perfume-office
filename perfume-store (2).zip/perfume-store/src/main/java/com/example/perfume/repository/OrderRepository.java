package com.example.perfume.repository;

import com.example.perfume.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserEmail(String email);
    Optional<Order> findByIdAndUserEmail(Long id, String email);
}
