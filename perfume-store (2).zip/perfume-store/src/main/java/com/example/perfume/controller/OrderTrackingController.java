package com.example.perfume.controller;

import com.example.perfume.model.Order;
import com.example.perfume.service.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/order-tracking")
public class OrderTrackingController {
    private final OrderService orderService;

    public OrderTrackingController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public String trackOrders(Model model, Principal principal) {
        List<Order> orders = orderService.getOrdersByEmail(principal.getName());
        model.addAttribute("orders", orders);
        return "order-tracking";
    }
}
