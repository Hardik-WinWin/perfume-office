package com.example.perfume.controller;

import com.example.perfume.model.Order;
import com.example.perfume.model.User;
import com.example.perfume.repository.OrderRepository;
import com.example.perfume.service.OrderService;
import com.example.perfume.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class OrderTrackingController {
    private final OrderService orderService;

    private final OrderRepository orderRepository;
    private final UserService userService;

    @GetMapping("/order-tracking")
    public String showOrderTrackingPage() {
        return "order-tracking";
    }

    @GetMapping("/track-order")
    public String trackOrder(@RequestParam String email, @RequestParam String orderId, Model model) {
        Optional<Order> order = orderService.getOrderByEmailAndOrderId(email, orderId);

        if (order.isPresent()) {
            model.addAttribute("order", order.get());
        } else {
            model.addAttribute("error", "No order found with the provided details.");
        }

        return "order-tracking";
    }
}
