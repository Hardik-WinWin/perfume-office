package com.example.perfume.model;

public enum OrderStatus {
    PENDING,
    CONFIRMED, // ✅ Add this to fix the issue
    FAILED,
    SHIPPED,
    DELIVERED,
    CANCELED
}
