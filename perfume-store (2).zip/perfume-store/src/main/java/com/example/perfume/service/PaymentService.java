package com.example.perfume.service;

import org.springframework.stereotype.Service;
import java.util.UUID;

@Service
public class PaymentService {

    public String generatePaymentId() {
        return "PAY-" + UUID.randomUUID().toString();
    }

    public String processPayment(String paymentId, double amount) {
        // Simulate payment success/failure (replace with real API later)
        return amount > 0 ? "SUCCESS" : "FAILED";
    }
}
