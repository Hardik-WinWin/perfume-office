package com.example.perfume.service;

import com.example.perfume.model.Perfume;
import com.example.perfume.repository.PerfumeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PerfumeService {

    @Autowired
    private PerfumeRepository perfumeRepository;

    public List<Perfume> getAllPerfumes() {
        return perfumeRepository.findAll();
    }

    public Optional<Perfume> getPerfumeById(Long id) {
        return perfumeRepository.findById(id);
    }

    public List<Perfume> getPerfumesByBrand(String brand) {
        return perfumeRepository.findByBrand(brand);
    }
}
