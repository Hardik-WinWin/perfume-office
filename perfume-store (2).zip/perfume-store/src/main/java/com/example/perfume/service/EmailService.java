package com.example.perfume.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String senderEmail;

    public void sendOrderConfirmation(String toEmail, String orderDetails) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setFrom(senderEmail);
        helper.setTo(toEmail);
        helper.setSubject("Order Confirmation - Perfume Store");

        String emailContent = "<h2>Thank You for Your Purchase!</h2>"
                + "<p>Your order details are as follows:</p>"
                + "<p>" + orderDetails + "</p>"
                + "<p>We hope you enjoy your new perfume!</p>";

        helper.setText(emailContent, true);
        mailSender.send(message);
    }
}
