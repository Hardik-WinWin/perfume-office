package com.example.perfume.controller;

import com.example.perfume.model.Order;
import com.example.perfume.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;

@Controller
@RequiredArgsConstructor
public class GuestCheckoutController {
    private final OrderRepository orderRepository;

    @GetMapping("/guest-checkout")
    public String guestCheckoutPage() {
        return "guest-checkout";
    }

    @PostMapping("/guest-checkout")
    public String placeGuestOrder(@RequestParam String guestEmail,
                                  @RequestParam String perfumeName,
                                  @RequestParam int quantity,
                                  @RequestParam double totalPrice,
                                  Model model) {
        Order order = new Order();
        order.setGuestEmail(guestEmail);
        order.setPerfumeName(perfumeName);
        order.setQuantity(quantity);
        order.setTotalPrice(totalPrice);
        order.setOrderDate(new Date());

        orderRepository.save(order);
        model.addAttribute("message", "Order placed successfully!");
        return "order-confirmation";
    }
}
