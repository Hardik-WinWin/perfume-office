package com.example.perfume.controller;

import com.example.perfume.model.Order;
import com.example.perfume.model.OrderStatus;
import com.example.perfume.service.OrderService;
import com.example.perfume.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;
import com.example.perfume.service.EmailService;
import com.example.perfume.service.InvoiceService;
import com.example.perfume.service.OrderService;
import com.example.perfume.service.RazorpayService;
import com.razorpay.RazorpayException;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.mail.javamail.JavaMailSender;
import jakarta.mail.internet.MimeMessage;

import java.io.ByteArrayInputStream;
import java.io.IOException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/payment")

public class PaymentController {

    private final RazorpayService razorpayService;
    private final EmailService emailService;
    private final InvoiceService invoiceService;
    private final JavaMailSender mailSender;

    private final PaymentService paymentService;
    private final OrderService orderService;

    // ✅ Process payment for both registered & guest users
    @PostMapping("/process")
    public ResponseEntity<Map<String, String>> processPayment(
            @RequestParam String email,
            @RequestParam double amount) {

        String paymentId = paymentService.generatePaymentId();
        String status = paymentService.processPayment(paymentId, amount);

        // ✅ Create order for both registered and guest users
        Order order = orderService.createOrder(paymentId, email, amount);

        if ("SUCCESS".equals(status)) {
            orderService.updateOrderStatus(paymentId, OrderStatus.CONFIRMED);
        } else {
            orderService.updateOrderStatus(paymentId, OrderStatus.FAILED);
        }

        return ResponseEntity.ok(Map.of(
                "paymentId", paymentId,
                "status", status
        ));
    }

    // ✅ Get payment details
    @GetMapping("/details")
    public ResponseEntity<?> getPaymentDetails(@RequestParam String paymentId) {
        Optional<Order> order = orderService.getOrderById(paymentId);

        if (order.isPresent()) {
            return ResponseEntity.ok(order.get());
        } else {
            return ResponseEntity.badRequest().body("No order found for Payment ID: " + paymentId);
        }
    }


    @GetMapping("/pay")
    public String createPayment(@RequestParam double amount, @RequestParam String email, Model model) {
        try {
            String order = razorpayService.createOrder(amount);
            model.addAttribute("order", order);
            model.addAttribute("email", email);
        } catch (RazorpayException e) {
            model.addAttribute("error", "Payment initialization failed!");
        }
        return "payment";
    }

    @GetMapping("/payment-success")
    public String paymentSuccess(@RequestParam String email, @RequestParam String orderId, @RequestParam double amount, Model model) {
        try {
            byte[] invoiceData = invoiceService.generateInvoice(orderId, email, amount);
            sendInvoiceEmail(email, orderId, invoiceData);
            model.addAttribute("message", "Payment successful! An invoice has been sent to your email.");
        } catch (MessagingException | IOException e) {
            model.addAttribute("error", "Payment successful, but invoice email failed to send.");
        }
        return "order-success";
    }

    private void sendInvoiceEmail(String toEmail, String orderId, byte[] invoiceData) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setFrom("hardikkashyap44@gmail.com");
        helper.setTo(toEmail);
        helper.setSubject("Invoice for Your Order - " + orderId);
        helper.setText("Dear Customer,\n\nThank you for your purchase! Please find your invoice attached.\n\nBest regards,\nPerfume Store");

        InputStreamSource attachment = new ByteArrayResource(invoiceData);
        helper.addAttachment("Invoice_" + orderId + ".pdf", attachment);

        mailSender.send(message);
    }
}
