package com.example.perfume.controller;

import com.example.perfume.model.Order;
import com.example.perfume.model.Payment;
import com.example.perfume.model.PaymentStatus;
import com.example.perfume.service.OrderService;
import com.example.perfume.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private OrderService orderService;

    @PostMapping("/process")
    public String processPayment(@RequestParam double amount) {
        Order order = new Order();
        order.setTotalAmount(amount); // ✅ This is fine

        // ✅ Properly setting the Payment object
        Payment payment = new Payment();
        payment.setAmount(amount);
        payment.setStatus(PaymentStatus.PENDING);

        order.setPayment(payment); // ✅ Assigning the Payment object correctly
        orderService.saveOrder(order);

        return "Payment processed successfully!";
    }
}
