package com.example.perfume.service;

import com.example.perfume.model.Order;
import com.example.perfume.model.Payment;
import com.example.perfume.model.PaymentStatus;
import com.example.perfume.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public List<Order> getOrdersByEmail(String email) {
        return orderRepository.findByUserEmail(email);
    }

    public Optional<Order> getOrderByIdAndEmail(Long id, String email) {
        return orderRepository.findByIdAndUserEmail(id, email);
    }

    public Order placeOrder(Order order, double amount) {
        Payment payment = new Payment();
        payment.setAmount(amount);
        payment.setStatus(PaymentStatus.PENDING);

        order.setPayment(payment); // ✅ Correct way to set payment
        return orderRepository.save(order);
    }

    public Order saveOrder(Order order) {
        return orderRepository.save(order); // ✅ Returns saved Order
    }
}
