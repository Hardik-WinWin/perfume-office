package com.example.perfume.service;

import com.example.perfume.model.Order;
import com.example.perfume.model.OrderStatus;
import com.example.perfume.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;

    public Order createOrder(String orderId, String email, double amount) {
        Order order = Order.builder()
                .orderId(orderId)
                .email(email)
                .amount(amount)
                .status(OrderStatus.PENDING)
                .orderDate(LocalDateTime.now())
                .build();
        return orderRepository.save(order);
    }

    public List<Order> getOrdersByEmail(String email) {
        return orderRepository.findByEmail(email);
    }

    // ✅ Fixed: Directly return the Optional<Order>
    public Optional<Order> getOrderById(String orderId) {
        return orderRepository.findByOrderId(orderId);
    }

    public Optional<Order> getOrderByEmailAndOrderId(String email, String orderId) {
        return orderRepository.findByEmailAndOrderId(email, orderId);
    }

    public void updateOrderStatus(String orderId, OrderStatus status) {
        Optional<Order> order = getOrderById(orderId);
        order.ifPresent(o -> {
            o.setStatus(status);
            orderRepository.save(o);
        });
    }
}
