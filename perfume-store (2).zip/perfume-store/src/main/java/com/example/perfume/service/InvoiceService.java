package com.example.perfume.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Service
public class InvoiceService {

    public byte[] generateInvoice(String orderId, String email, double amount) throws IOException {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);
            contentStream.beginText();
            contentStream.newLineAtOffset(100, 700);
            contentStream.showText("Perfume Store - Invoice");
            contentStream.endText();

            contentStream.setFont(PDType1Font.HELVETICA, 14);
            contentStream.beginText();
            contentStream.newLineAtOffset(100, 650);
            contentStream.showText("Order ID: " + orderId);
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Customer Email: " + email);
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Total Amount: ₹" + amount);
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Thank you for your purchase!");
            contentStream.endText();
        }

        document.save(outputStream);
        document.close();
        return outputStream.toByteArray();
    }
}
