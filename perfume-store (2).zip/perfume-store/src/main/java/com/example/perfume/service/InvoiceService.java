package com.example.perfume.service;

import com.example.perfume.model.Order;
import org.springframework.stereotype.Service;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;

@Service
public class InvoiceService {

    public byte[] generateInvoice(Order order) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, outputStream);
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

            document.add(new Paragraph("Perfume Store - Invoice", titleFont));
            document.add(new Paragraph("------------------------------------------------------"));
            document.add(new Paragraph("Order ID: " + order.getId(), normalFont));
            document.add(new Paragraph("Date: " + new Date(), normalFont));
            document.add(new Paragraph("Customer Email: " + order.getUser().getEmail(), normalFont));
            document.add(new Paragraph("Perfume Name: " + order.getPerfume().getName(), normalFont));
            document.add(new Paragraph("Quantity: " + order.getQuantity(), normalFont));
            document.add(new Paragraph("Total Price: $" + order.getTotalPrice(), normalFont));
            document.add(new Paragraph("------------------------------------------------------"));
            document.add(new Paragraph("Thank you for your purchase!", normalFont));

            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        return outputStream.toByteArray();
    }
}
