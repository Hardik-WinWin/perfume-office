package com.example.perfume.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "perfume_id")
    private Perfume perfume;

    private int quantity;
    private double totalPrice;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    private LocalDateTime orderDate;
    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    // ✅ Overloaded method to allow setting status using a String
    public void setStatus(String statusString) {
        this.status = OrderStatus.fromString(statusString);
    }

    private double totalAmount; // ✅ Correct type for price-related values

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "payment_id", referencedColumnName = "id")
    private Payment payment; // ✅ Ensure this is of type Payment
}
