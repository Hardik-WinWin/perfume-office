package com.example.perfume.model;

import jakarta.persistence.*;
import lombok.*;
//import java.util.Date;
import java.time.LocalDateTime;




@Entity
@Table(name = "orders")
@Getter
@Setter
@Builder // ✅ Ensure @Builder is here
@NoArgsConstructor
@AllArgsConstructor
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = true)
    private User user; // Nullable for guest users

    @Column(nullable = false)
    private String guestEmail; // For guest checkout

    private String perfumeName;
    private int quantity;
    private double totalPrice;
//    private Date orderDate;

    private String orderId;
    private String email;
    private double amount;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    @Column(name = "order_date", nullable = false, updatable = false)
    private LocalDateTime orderDate;
}
